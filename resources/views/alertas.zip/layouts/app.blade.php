<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}"/>
    <title>@yield('title') | {{ config('app.name') }}</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 4.1.1 -->
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css"/>
    <!-- Ionicons -->
    <link href="//fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">
    <link href="{{ asset('assets/css/@fortawesome/fontawesome-free/css/all.css') }}" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="{{ asset('assets/css/iziToast.min.css') }}">
    <link href="{{ asset('assets/css/sweetalert.css') }}" rel="stylesheet" type="text/css"/>
    <link href="{{ asset('assets/css/select2.min.css') }}" rel="stylesheet" type="text/css"/>

@yield('page_css')
<!-- Template CSS -->
    <link rel="stylesheet" href="{{ asset('web/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('web/css/components.css')}}">
    <link rel="stylesheet" href="{{ asset('web/css/custom-tables.css')}}">

    @yield('css')
</head>
<body>

<div id="app">
    <div class="main-wrapper main-wrapper-1">
        <div class="navbar-bg"></div>
        <nav class="navbar navbar-expand-lg main-navbar">
            @include('layouts.header')

        </nav>
        <div class="main-sidebar main-sidebar-postion">
            @include('layouts.sidebar')
        </div>
        <!-- Main Content -->
        <div class="main-content">
            @yield('content')
        </div>
        <footer class="main-footer">
            @include('layouts.footer')
        </footer>
    </div>
</div>

</body>
<script src="{{ asset('assets/js/jquery.min.js') }}"></script>
<script src="{{ asset('assets/js/popper.min.js') }}"></script>
<script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('assets/js/sweetalert.min.js') }}"></script>
<script src="{{ asset('assets/js/iziToast.min.js') }}"></script>
<script src="{{ asset('assets/js/select2.min.js') }}"></script>
<script src="{{ asset('assets/js/jquery.nicescroll.js') }}"></script>

<!-- Template JS File -->
<script src="{{ asset('web/js/stisla.js') }}"></script>
<script src="{{ asset('web/js/scripts.js') }}"></script>
<script src="{{ asset('web/js/custom-tables.js') }}"></script>
<script src="{{ mix('assets/js/profile.js') }}"></script>
<script src="{{ mix('assets/js/custom/custom.js') }}"></script>

@include('layouts.partials.loader-reportes')

@include('profile.change_password')
@include('profile.edit_profile')

@yield('page_js')
@yield('scripts')
<script>
    let loggedInUser =@json(\Illuminate\Support\Facades\Auth::user());
    let loginUrl = '{{ route('login') }}';
    const userUrl = '{{url('users')}}';
    // Loading button plugin (removed from BS4)
    (function ($) {
        $.fn.button = function (action) {
            if (action === 'loading' && this.data('loading-text')) {
                this.data('original-text', this.html()).html(this.data('loading-text')).prop('disabled', true);
            }
            if (action === 'reset' && this.data('original-text')) {
                this.html(this.data('original-text')).prop('disabled', false);
            }
        };
    }(jQuery));

    // Auto-scroll sidebar cuando se expande un menú
    $(document).ready(function() {
        $('.menu-toggle').on('shown.bs.collapse', function(e) {
            const $sidebar = $('.main-sidebar');
            const $menuItem = $(this).closest('.side-menus');
            const targetId = $(this).attr('data-target');
            const $submenu = $(targetId);
            
            if ($menuItem.length && $menuItem.offset()) {
                const menuBottom = $menuItem.offset().top + $menuItem.outerHeight() + $submenu.outerHeight();
                const sidebarBottom = $sidebar.offset().top + $sidebar.height();
                
                if (menuBottom > sidebarBottom) {
                    const scrollAmount = menuBottom - sidebarBottom + 20;
                    $sidebar.animate({
                        scrollTop: $sidebar.scrollTop() + scrollAmount
                    }, 300);
                }
            }
        });
        
        $('.main-sidebar [data-toggle="collapse"]').on('click', function() {
            const $this = $(this);
            const targetId = $this.attr('data-target');
            
            $(targetId).on('shown.bs.collapse', function() {
                const $sidebar = $('.main-sidebar');
                const $menuItem = $this.closest('.side-menus');
                const $submenu = $(this);
                
                if ($menuItem.length && $menuItem.offset()) {
                    const menuBottom = $menuItem.offset().top + $menuItem.outerHeight() + $submenu.outerHeight();
                    const sidebarBottom = $sidebar.offset().top + $sidebar.height();
                    
                    if (menuBottom > sidebarBottom) {
                        const scrollAmount = menuBottom - sidebarBottom + 20;
                        $sidebar.animate({
                            scrollTop: $sidebar.scrollTop() + scrollAmount
                        }, 300);
                    }
                }
            });
        });
    });
</script>
</html>
