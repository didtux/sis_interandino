@extends('layouts.app')

@section('content')
<div class="section-body">
    <div class="row">
        <div class="col-12">
            <div class="card modern-card">
                <div class="card-header">
                    <h4><i class="fas fa-shopping-cart mr-2"></i>Nueva Venta</h4>
                </div>
                <div class="card-body">
                    <form id="form-venta">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Cliente <span class="text-danger">*</span></label>
                                    <input type="text" id="ven_cliente" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Celular</label>
                                    <input type="text" id="ven_celular" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Dirección</label>
                                    <input type="text" id="ven_direccion" class="form-control">
                                </div>
                            </div>
                        </div>

                        <hr>
                        <h5>Agregar Productos</h5>
                        
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label><i class="fas fa-qrcode"></i> Escanear código (QR o barras)</label>
                                    <div class="input-group">
                                        <input type="text" id="barcode-input" class="form-control form-control-lg" placeholder="Escanee la etiqueta aquí..." autocomplete="off">
                                        <div class="input-group-append">
                                            <button type="button" class="btn btn-info" onclick="focusBarcode()">
                                                <i class="fas fa-barcode"></i> Listo para escanear
                                            </button>
                                            <button type="button" class="btn btn-outline-primary" id="btn-camara" onclick="alternarCamara()">
                                                <i class="fas fa-camera"></i> Usar cámara
                                            </button>
                                        </div>
                                    </div>
                                    <small class="text-muted">Con la pistola o la cámara: cada lectura suma una unidad (como venta o préstamo, según "Tipo").</small>
                                    <div id="qr-reader-ventas" style="display:none;max-width:420px;" class="mt-2"></div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Producto</label>
                                    <select id="producto-select" class="form-control select2" multiple>
                                        @foreach($productos as $p)
                                            <option value="{{ $p->prod_codigo }}" 
                                                data-precio="{{ $p->prod_preciounitario }}" 
                                                data-stock="{{ $p->prod_cantidad }}"
                                                data-nombre="{{ $p->prod_nombre }}"
                                                data-item="{{ $p->prod_item }}">
                                                {{ $p->prod_nombre }} (Stock: {{ $p->prod_cantidad }}) - Bs. {{ number_format($p->prod_preciounitario, 2) }}
                                            </option>
                                        @endforeach
                                    </select>
                                    <small class="text-muted">Seleccione múltiples productos y presione "Agregar Seleccionados"</small>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Cantidad</label>
                                    <input type="number" id="cantidad" class="form-control" min="1" value="1">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Tipo</label>
                                    <select id="tipo" class="form-control">
                                        <option value="venta">Venta</option>
                                        <option value="prestamo">Préstamo</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>&nbsp;</label>
                                    <button type="button" class="btn btn-success btn-block" onclick="agregarSeleccionados()">
                                        <i class="fas fa-plus"></i> Agregar Seleccionados
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="table-responsive mt-3">
                            <table class="table table-bordered">
                                <thead class="bg-primary text-white">
                                    <tr>
                                        <th class="text-white">Producto</th>
                                        <th class="text-white">Cantidad</th>
                                        <th class="text-white">Precio Unit.</th>
                                        <th class="text-white">Tipo</th>
                                        <th class="text-white">Subtotal</th>
                                        <th class="text-white">Acción</th>
                                    </tr>
                                </thead>
                                <tbody id="lista-productos">
                                    <tr>
                                        <td colspan="6" class="text-center text-muted">No hay productos agregados</td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="4" class="text-right"><strong>TOTAL:</strong></td>
                                        <td colspan="2"><strong>Bs. <span id="total-venta">0.00</span></strong></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                        <div class="form-group mt-3">
                            <button type="button" class="btn btn-primary" onclick="mostrarConfirmacion()">
                                <i class="fas fa-save"></i> Registrar Venta
                            </button>
                            <a href="{{ route('ventas.index') }}" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancelar
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- Modal de confirmación --}}
<div class="modal fade" id="modalConfirmar" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-check-circle mr-2"></i>Confirmar Venta</h5>
                <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Cliente:</strong> <span id="conf_cliente"></span></div>
                    <div class="col-md-4"><strong>Celular:</strong> <span id="conf_celular"></span></div>
                    <div class="col-md-4"><strong>Dirección:</strong> <span id="conf_direccion"></span></div>
                </div>
                <table class="table table-bordered table-sm">
                    <thead class="thead-light">
                        <tr>
                            <th>Producto</th>
                            <th>Cant.</th>
                            <th>Precio Unit.</th>
                            <th>Tipo</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody id="conf_productos"></tbody>
                    <tfoot>
                        <tr class="table-success">
                            <td colspan="4" class="text-right"><strong>TOTAL:</strong></td>
                            <td><strong>Bs. <span id="conf_total"></span></strong></td>
                        </tr>
                    </tfoot>
                </table>
                <div class="alert alert-warning py-2 mb-0">
                    <i class="fas fa-exclamation-triangle mr-1"></i> ¿Está seguro de registrar esta venta? Esta acción descontará el stock de los productos.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" onclick="guardarVenta()">
                    <i class="fas fa-check mr-1"></i>Confirmar y Registrar
                </button>
            </div>
        </div>
    </div>
</div>

<script>
let productosVenta = [];

function agregarSeleccionados() {
    const select = document.getElementById('producto-select');
    const selectedOptions = Array.from(select.selectedOptions);
    
    if (selectedOptions.length === 0) {
        alert('Seleccione al menos un producto');
        return;
    }
    
    const cantidad = parseInt(document.getElementById('cantidad').value);
    const tipo = document.getElementById('tipo').value;
    
    selectedOptions.forEach(option => {
        const stock = parseInt(option.dataset.stock);
        
        if (cantidad > stock) {
            alert(`Stock insuficiente para ${option.dataset.nombre}. Disponible: ${stock}`);
            return;
        }
        
        const producto = {
            prod_codigo: option.value,
            prod_nombre: option.dataset.nombre,
            cantidad: cantidad,
            precio: parseFloat(option.dataset.precio),
            tipo: tipo,
            subtotal: cantidad * parseFloat(option.dataset.precio)
        };
        
        productosVenta.push(producto);
    });
    
    actualizarTabla();
    
    // Limpiar selección pero mantener el select abierto
    $('#producto-select').val(null).trigger('change');
    document.getElementById('cantidad').value = 1;
}

function agregarProducto() {
    const select = document.getElementById('producto-select');
    const option = select.options[select.selectedIndex];
    
    if (!option.value) {
        alert('Seleccione un producto');
        return;
    }
    
    const cantidad = parseInt(document.getElementById('cantidad').value);
    const stock = parseInt(option.dataset.stock);
    
    if (cantidad > stock) {
        alert('Stock insuficiente. Disponible: ' + stock);
        return;
    }
    
    const producto = {
        prod_codigo: option.value,
        prod_nombre: option.dataset.nombre || option.text.split(' (Stock:')[0],
        cantidad: cantidad,
        precio: parseFloat(option.dataset.precio),
        tipo: document.getElementById('tipo').value,
        subtotal: cantidad * parseFloat(option.dataset.precio)
    };
    
    productosVenta.push(producto);
    actualizarTabla();
    
    $('#producto-select').val('').trigger('change');
    document.getElementById('cantidad').value = 1;
}

function eliminarProducto(index) {
    productosVenta.splice(index, 1);
    actualizarTabla();
}

function actualizarTabla() {
    const tbody = document.getElementById('lista-productos');
    tbody.innerHTML = '';
    
    if (productosVenta.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No hay productos agregados</td></tr>';
        document.getElementById('total-venta').textContent = '0.00';
        return;
    }
    
    let total = 0;
    productosVenta.forEach((p, index) => {
        total += p.subtotal;
        tbody.innerHTML += `
            <tr>
                <td>${p.prod_nombre}</td>
                <td>${p.cantidad}</td>
                <td>Bs. ${p.precio.toFixed(2)}</td>
                <td><span class="badge badge-${p.tipo === 'venta' ? 'success' : 'warning'}">${p.tipo}</span></td>
                <td>Bs. ${p.subtotal.toFixed(2)}</td>
                <td>
                    <button type="button" class="btn btn-sm btn-danger" onclick="eliminarProducto(${index})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    });
    
    document.getElementById('total-venta').textContent = total.toFixed(2);
}

function mostrarConfirmacion() {
    const cliente = document.getElementById('ven_cliente').value.trim();
    if (!cliente) {
        alert('Debe ingresar el nombre del cliente');
        document.getElementById('ven_cliente').focus();
        return;
    }
    if (productosVenta.length === 0) {
        alert('Agregue al menos un producto');
        return;
    }

    // Llenar modal
    document.getElementById('conf_cliente').textContent = cliente;
    document.getElementById('conf_celular').textContent = document.getElementById('ven_celular').value || '-';
    document.getElementById('conf_direccion').textContent = document.getElementById('ven_direccion').value || '-';

    let html = '';
    let total = 0;
    productosVenta.forEach(function(p) {
        total += p.subtotal;
        html += '<tr>' +
            '<td>' + p.prod_nombre + '</td>' +
            '<td>' + p.cantidad + '</td>' +
            '<td>Bs. ' + p.precio.toFixed(2) + '</td>' +
            '<td><span class="badge badge-' + (p.tipo === 'venta' ? 'success' : 'warning') + '">' + p.tipo + '</span></td>' +
            '<td>Bs. ' + p.subtotal.toFixed(2) + '</td>' +
            '</tr>';
    });
    document.getElementById('conf_productos').innerHTML = html;
    document.getElementById('conf_total').textContent = total.toFixed(2);
    $('#modalConfirmar').modal('show');
}

function guardarVenta() {
    $('#modalConfirmar').modal('hide');
    // La pestaña del ticket se abre acá, dentro del clic: si se abre recién
    // cuando responde el servidor, el bloqueador de ventanas emergentes la
    // frena y el ticket no sale. Se carga el recibo cuando llega la respuesta.
    const ventanaTicket = window.open('', '_blank');
    if (ventanaTicket) ventanaTicket.document.write('<p style="font-family:sans-serif">Generando ticket…</p>');
    const data = {
        ven_cliente: document.getElementById('ven_cliente').value,
        ven_celular: document.getElementById('ven_celular').value,
        ven_direccion: document.getElementById('ven_direccion').value,
        productos: productosVenta,
        _token: '{{ csrf_token() }}'
    };
    
    fetch('{{ route("ventas.store") }}', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // El ticket sale solo al cerrar la venta: antes había que buscar la
            // venta en el listado para poder imprimir el comprobante.
            if (data.recibo_url && ventanaTicket) {
                ventanaTicket.location.href = data.recibo_url;
            } else if (data.recibo_url) {
                window.open(data.recibo_url, '_blank');
            } else if (ventanaTicket) {
                ventanaTicket.close();
            }
            alert('Venta ' + (data.ven_codigo || '') + ' registrada. Total Bs. ' + Number(data.total).toFixed(2));
            window.location.href = '{{ route("ventas.index") }}';
        } else {
            if (ventanaTicket) ventanaTicket.close();
            alert('Error: ' + data.message);
        }
    })
    .catch(error => {
        if (ventanaTicket) ventanaTicket.close();
        alert('Error al registrar la venta');
        console.error(error);
    });
}
</script>
@endsection

@push('scripts')
<script src="{{ asset('vendor/html5-qrcode/html5-qrcode.min.js') }}"></script>
<script>
$(document).ready(function() {
    $('#producto-select').select2({
        placeholder: 'Buscar productos...',
        width: '100%',
        closeOnSelect: false,
        allowClear: true
    });

    // La pistola escribe el código y manda Enter
    $('#barcode-input').focus().on('keydown', function(e) {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        var texto = $(this).val();
        $(this).val('');
        buscarYAgregarProducto(texto, false);
    });
});

function focusBarcode() {
    $('#barcode-input').focus();
}

/**
 * Agrega el producto leído por la pistola o la cámara. Se busca en la lista
 * que ya está en la página (por código de ítem o código de producto), sin
 * consultar al servidor; antes se hacía una consulta síncrona por cada
 * producto del catálogo (~215) en cada lectura. Las etiquetas viejas traen
 * "codigo|nombre|categoría|precio": se usa la primera parte.
 */
var ultimoCodigo = '', ultimoMomento = 0;
function buscarYAgregarProducto(texto, desdeCamara) {
    var codigo = (texto || '').split('|')[0].trim();
    if (!codigo) return;

    // La cámara lee el mismo código varias veces por segundo
    var ahora = Date.now();
    if (desdeCamara && codigo === ultimoCodigo && (ahora - ultimoMomento) < 3000) return;
    ultimoCodigo = codigo; ultimoMomento = ahora;

    var buscado = codigo.toLowerCase();
    var $opt = $('#producto-select option').filter(function() {
        return this.value.toLowerCase() === buscado || String($(this).attr('data-item') || '').toLowerCase() === buscado;
    }).first();

    if ($opt.length) { agregarPorLectura($opt[0]); return; }

    $.getJSON('{{ url("/api/producto-por-barcode") }}/' + encodeURIComponent(codigo))
        .done(function(d) { avisoLectura(d.found ? '«' + d.prod_nombre + '» no está disponible para la venta' : 'Producto no encontrado: ' + codigo, false); })
        .fail(function() { avisoLectura('Producto no encontrado: ' + codigo, false); });
}

/** Suma 1 unidad del producto (o crea la fila), respetando el stock. */
function agregarPorLectura(option) {
    var stock = parseInt(option.dataset.stock) || 0;
    var precio = parseFloat(option.dataset.precio) || 0;
    var nombre = option.dataset.nombre;
    var tipo = document.getElementById('tipo').value;
    var enLista = productosVenta.filter(function(p) { return p.prod_codigo === option.value; })
                                .reduce(function(t, p) { return t + p.cantidad; }, 0);
    if (enLista + 1 > stock) { avisoLectura('Stock insuficiente de ' + nombre + ' (disponible: ' + stock + ')', false); return; }

    var fila = productosVenta.find(function(p) { return p.prod_codigo === option.value && p.tipo === tipo; });
    if (fila) {
        fila.cantidad++;
        fila.subtotal = fila.cantidad * fila.precio;
    } else {
        productosVenta.push({ prod_codigo: option.value, prod_nombre: nombre, cantidad: 1, precio: precio, tipo: tipo, subtotal: precio });
    }
    actualizarTabla();
    avisoLectura(nombre + (fila ? ' (x' + fila.cantidad + ')' : '') + ' agregado', true);
}

function avisoLectura(mensaje, ok) {
    $('#barcode-input').toggleClass('is-valid', ok).toggleClass('is-invalid', !ok);
    setTimeout(function() { $('#barcode-input').removeClass('is-valid is-invalid'); }, 1200);
    if (window.iziToast) iziToast[ok ? 'success' : 'error']({ message: mensaje, position: 'topRight', timeout: ok ? 1500 : 3000 });
    else if (!ok) alert(mensaje);
}

// ── Lector con la cámara (celular o webcam) ─────────────────────────────────
var lectorCamara = null;
function alternarCamara() {
    if (lectorCamara) {
        lectorCamara.clear().catch(function() {});
        lectorCamara = null;
        $('#qr-reader-ventas').hide();
        $('#btn-camara').html('<i class="fas fa-camera"></i> Usar cámara');
        focusBarcode();
        return;
    }
    if (typeof Html5QrcodeScanner === 'undefined') { alert('No se pudo cargar el lector de la cámara.'); return; }
    $('#qr-reader-ventas').show();
    $('#btn-camara').html('<i class="fas fa-stop"></i> Cerrar cámara');
    lectorCamara = new Html5QrcodeScanner('qr-reader-ventas', { fps: 10, qrbox: 230, rememberLastUsedCamera: true });
    lectorCamara.render(function(texto) { buscarYAgregarProducto(texto, true); });
}
</script>
@endpush
