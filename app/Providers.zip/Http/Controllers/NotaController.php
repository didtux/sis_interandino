<?php

namespace App\Http\Controllers;

use App\Models\Nota;
use App\Models\NotaDetalle;
use App\Models\NotaPeriodo;
use App\Models\NotaDimension;
use App\Models\CursoMateriaDocente;
use App\Models\Estudiante;
use App\Models\ListaCurso;
use App\Models\Curso;
use App\Models\Materia;
use App\Models\Asistencia;
use App\Models\AsistenciaClase;
use App\Models\Atraso;
use App\Models\Permiso;
use App\Models\RegistroEnfermeria;
use App\Models\CasoPsicopedagogia;
use App\Models\FechaFestiva;
use App\Models\MateriaGrupo;
use App\Models\ImportacionExcel;
use App\Services\ImportarExcelService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;

class NotaController extends Controller
{
    public function index(Request $request)
    {
        $user = auth()->user();
        $gestion = date('Y');
        $periodos = NotaPeriodo::activo()->gestion($gestion)->orderBy('periodo_numero')->get();
        $dimensiones = NotaDimension::activo()->gestion($gestion)->orderBy('dimension_orden')->get();

        $query = CursoMateriaDocente::with(['curso', 'materia', 'docente'])->where('curmatdoc_estado', 1);

        if ($user->us_entidad_tipo === 'docente' && $user->us_entidad_id) {
            $query->where('doc_codigo', $user->us_entidad_id);
        }
        if ($request->filled('cur_codigo')) {
            $curCodigos = is_array($request->cur_codigo) ? $request->cur_codigo : [$request->cur_codigo];
            $query->whereIn('cur_codigo', $curCodigos);
        }
        if ($request->filled('mat_codigo')) {
            $matCodigos = is_array($request->mat_codigo) ? $request->mat_codigo : [$request->mat_codigo];
            $query->whereIn('mat_codigo', $matCodigos);
        }
        if ($request->filled('buscar')) {
            // Resolver doc_codigos en consulta separada para evitar colación mixta en JOIN.
            $tokens = preg_split('/\s+/', trim($request->buscar), -1, PREG_SPLIT_NO_EMPTY);
            $docQ = \DB::table('colegio_docentes');
            foreach ($tokens as $t) {
                $docQ->where(function($qq) use ($t) {
                    $qq->where('doc_nombres', 'like', "%$t%")
                       ->orWhere('doc_apellidos', 'like', "%$t%")
                       ->orWhere('doc_codigo', 'like', "%$t%");
                });
            }
            $docCodigos = $docQ->pluck('doc_codigo')->all();
            $query->whereIn('doc_codigo', $docCodigos ?: ['__none__']);
        }
        if ($request->filled('estado')) {
            $estadoFiltro = intval($request->estado);
            $query->whereHas('notas', fn($q) => $q->where('nota_estado', $estadoFiltro));
        }

        $asignaciones = $query->get();

        // Filtrar cursos y materias según el rol
        if ($user->us_entidad_tipo === 'docente' && $user->us_entidad_id) {
            $misAsignaciones = CursoMateriaDocente::where('curmatdoc_estado', 1)
                ->where('doc_codigo', $user->us_entidad_id)->get();
            $misCurCodigos = $misAsignaciones->pluck('cur_codigo')->unique();
            $misMatCodigos = $misAsignaciones->pluck('mat_codigo')->unique();
            $cursos   = \App\Models\Curso::visible()->whereIn('cur_codigo', $misCurCodigos)->orderBy('cur_nombre')->get();
            $materias = \App\Models\Materia::visible()->whereIn('mat_codigo', $misMatCodigos)->orderBy('mat_nombre')->get();
        } else {
            $cursos   = \App\Models\Curso::visible()->orderBy('cur_nombre')->get();
            $materias = \App\Models\Materia::visible()->orderBy('mat_nombre')->get();
        }

        // ── Datos del Dashboard ──────────────────────────────────────────────
        $periodoIds = $periodos->pluck('periodo_id');

        $statAprobadas  = Nota::whereIn('periodo_id', $periodoIds)->where('nota_estado', 2)->count();
        $statEnviadas   = Nota::whereIn('periodo_id', $periodoIds)->where('nota_estado', 1)->count();
        $statBorradores = Nota::whereIn('periodo_id', $periodoIds)->where('nota_estado', 0)->count();
        $statRechazadas = Nota::whereIn('periodo_id', $periodoIds)->where('nota_estado', 3)->count();

        // Ranking: top 10 estudiantes (solo notas aprobadas)
        $ranking = DB::table('colegio_notas as n')
            ->join('colegio_estudiantes as e', DB::raw('n.est_codigo COLLATE utf8mb4_unicode_ci'), '=', DB::raw('e.est_codigo COLLATE utf8mb4_unicode_ci'))
            ->join('colegio_cursos as c', DB::raw('e.cur_codigo COLLATE utf8mb4_unicode_ci'), '=', DB::raw('c.cur_codigo COLLATE utf8mb4_unicode_ci'))
            ->whereIn('n.periodo_id', $periodoIds)
            ->where('n.nota_estado', 2)
            ->where('n.nota_promedio_trimestral', '>', 0)
            ->select(
                'n.est_codigo',
                'e.est_nombres', 'e.est_apellidos',
                'c.cur_nombre',
                DB::raw('ROUND(AVG(COALESCE(n.nota_promedio_decimal, n.nota_promedio_trimestral)), 1) as promedio')
            )
            ->groupBy('n.est_codigo', 'e.est_nombres', 'e.est_apellidos', 'c.cur_nombre')
            ->orderByDesc('promedio')
            ->limit(10)
            ->get();

        // Estudiantes en peligro (promedio < 51)
        $enPeligro = DB::table('colegio_notas as n')
            ->join('colegio_estudiantes as e', DB::raw('n.est_codigo COLLATE utf8mb4_unicode_ci'), '=', DB::raw('e.est_codigo COLLATE utf8mb4_unicode_ci'))
            ->join('colegio_cursos as c', DB::raw('e.cur_codigo COLLATE utf8mb4_unicode_ci'), '=', DB::raw('c.cur_codigo COLLATE utf8mb4_unicode_ci'))
            ->whereIn('n.periodo_id', $periodoIds)
            ->where('n.nota_estado', 2)
            ->where('n.nota_promedio_trimestral', '>', 0)
            ->select(
                'n.est_codigo',
                'e.est_nombres', 'e.est_apellidos',
                'c.cur_nombre',
                DB::raw('ROUND(AVG(COALESCE(n.nota_promedio_decimal, n.nota_promedio_trimestral)), 1) as promedio')
            )
            ->groupBy('n.est_codigo', 'e.est_nombres', 'e.est_apellidos', 'c.cur_nombre')
            ->having('promedio', '<', 51)
            ->orderBy('promedio')
            ->limit(10)
            ->get();

        // Todos los estudiantes (para selector de reporte personal)
        // Docentes: solo estudiantes de sus cursos asignados
        if ($user->us_entidad_tipo === 'docente' && $user->us_entidad_id) {
            $todosEstudiantes = Estudiante::visible()
                ->whereIn('cur_codigo', $misCurCodigos)
                ->select('est_codigo', 'est_nombres', 'est_apellidos', 'cur_codigo')
                ->orderBy('est_apellidos')->get();
        } else {
            $todosEstudiantes = Estudiante::visible()
                ->select('est_codigo', 'est_nombres', 'est_apellidos', 'cur_codigo')
                ->orderBy('est_apellidos')->get();
        }

        // Lista de docentes para el filtro (solo para roles no-docentes).
        // Anexamos cursos y materias asignados para el dropdown dependiente.
        $docentesList = collect();
        $docenteAsignaciones = [];
        if (!($user->us_entidad_tipo === 'docente' && $user->us_entidad_id)) {
            $docentesList = \App\Models\Docente::orderBy('doc_apellidos')->orderBy('doc_nombres')
                ->get(['doc_codigo','doc_nombres','doc_apellidos']);

            // Mapa doc_codigo => { cursos: [...], materias: [...] }
            $asigs = CursoMateriaDocente::where('curmatdoc_estado', 1)
                ->select('doc_codigo', 'cur_codigo', 'mat_codigo')->get();
            foreach ($asigs as $a) {
                $code = (string) $a->doc_codigo;
                if (!isset($docenteAsignaciones[$code])) {
                    $docenteAsignaciones[$code] = ['cursos' => [], 'materias' => []];
                }
                if ($a->cur_codigo && !in_array($a->cur_codigo, $docenteAsignaciones[$code]['cursos'])) {
                    $docenteAsignaciones[$code]['cursos'][] = $a->cur_codigo;
                }
                if ($a->mat_codigo && !in_array($a->mat_codigo, $docenteAsignaciones[$code]['materias'])) {
                    $docenteAsignaciones[$code]['materias'][] = $a->mat_codigo;
                }
            }

            // Diccionario nombre completo => doc_codigo (para mapear desde el value del select).
            // El filtro de búsqueda funciona por nombre completo (el value del option).
        }

        return view('notas.index', compact(
            'asignaciones', 'periodos', 'dimensiones', 'cursos', 'materias',
            'statAprobadas', 'statEnviadas', 'statBorradores', 'statRechazadas',
            'ranking', 'enPeligro', 'todosEstudiantes', 'gestion', 'docentesList',
            'docenteAsignaciones'
        ));
    }

    /**
     * Aprobación masiva: recibe arr de pares (curmatdoc_id, periodo_id) y aprueba.
     */
    public function aprobarMasivo(Request $request)
    {
        $request->validate([
            'items' => 'required|array|min:1',
        ]);

        $aprobados = 0;
        foreach ($request->items as $pair) {
            if (!preg_match('/^\d+\|\d+$/', $pair)) continue;
            [$cmd, $pid] = explode('|', $pair);
            $updated = Nota::where('curmatdoc_id', $cmd)
                ->where('periodo_id', $pid)
                ->where('nota_estado', 1) // solo enviadas (no toca aprobadas/rechazadas)
                ->update([
                    'nota_estado' => 2,
                    'nota_fecha_aprobacion' => now(),
                    'nota_aprobado_por' => auth()->user()->us_id,
                    'nota_observacion' => null,
                ]);
            if ($updated) $aprobados++;
        }
        return back()->with('success', "Aprobación masiva: $aprobados asignación(es) aprobadas.");
    }

    /**
     * Vista Rendimiento: matriz estudiantes × materias con promedio trimestral.
     */
    public function rendimiento(Request $request)
    {
        $gestion = date('Y');
        $periodos = NotaPeriodo::activo()->gestion($gestion)->orderBy('periodo_numero')->get();
        $cursos   = Curso::visible()->ordenado()->get();

        $cursoCod  = $request->input('cur_codigo');
        $periodoId = $request->input('periodo_id', optional($periodos->first())->periodo_id);
        $buscar    = trim((string) $request->input('buscar', ''));

        $estudiantes = collect();
        $materias    = collect();
        $matriz      = []; // [est_codigo][mat_codigo] => promedio
        $asignaciones = collect();

        if ($cursoCod && $periodoId) {
            $asignaciones = CursoMateriaDocente::with('materia')
                ->where('cur_codigo', $cursoCod)
                ->where('curmatdoc_estado', 1)
                ->get();

            $materias = $asignaciones->pluck('materia')->filter()->sortBy('mat_orden')->values();

            $eq = Estudiante::where('colegio_estudiantes.cur_codigo', $cursoCod)
                ->leftJoin('colegio_lista_curso', function($j) use ($gestion, $cursoCod){
                    $j->whereRaw('colegio_estudiantes.est_codigo COLLATE utf8mb4_unicode_ci = colegio_lista_curso.est_codigo COLLATE utf8mb4_unicode_ci')
                      ->where('colegio_lista_curso.lista_gestion', $gestion)
                      ->where('colegio_lista_curso.cur_codigo', $cursoCod);
                })
                ->select('colegio_estudiantes.*', 'colegio_lista_curso.lista_numero');

            if ($buscar !== '') {
                $eq->where(function($w) use ($buscar) {
                    $w->where('colegio_estudiantes.est_nombres','like',"%{$buscar}%")
                      ->orWhere('colegio_estudiantes.est_apellidos','like',"%{$buscar}%");
                });
            }

            $estudiantes = $eq->orderByRaw('colegio_lista_curso.lista_numero IS NULL ASC')
                ->orderBy('colegio_lista_curso.lista_numero','asc')
                ->orderBy('colegio_estudiantes.est_apellidos')
                ->get();

            $curmatIds = $asignaciones->pluck('curmatdoc_id');
            $notas = Nota::whereIn('curmatdoc_id', $curmatIds)
                ->where('periodo_id', $periodoId)
                ->get();

            $asignByCurmat = $asignaciones->keyBy('curmatdoc_id');
            foreach ($notas as $n) {
                $matCod = optional($asignByCurmat->get($n->curmatdoc_id))->mat_codigo;
                if ($matCod) {
                    $matriz[$n->est_codigo][$matCod] = [
                        'promedio' => $n->nota_promedio_trimestral,
                        'curmatdoc_id' => $n->curmatdoc_id,
                        'nota_id' => $n->nota_id,
                    ];
                }
            }
        }

        return view('notas.rendimiento', compact(
            'periodos','cursos','cursoCod','periodoId','buscar',
            'estudiantes','materias','matriz','asignaciones','gestion'
        ));
    }

    public function calificar($curmatdocId, $periodoId)
    {
        $asignacion = CursoMateriaDocente::with(['curso', 'materia', 'docente'])->findOrFail($curmatdocId);
        $periodo = NotaPeriodo::findOrFail($periodoId);
        $gestion = $periodo->periodo_gestion;
        $dimensiones = NotaDimension::activo()->gestion($gestion)->orderBy('dimension_orden')->get();

        $user = auth()->user();
        if ($user->us_entidad_tipo === 'docente' && $user->us_entidad_id && $user->us_entidad_id !== $asignacion->doc_codigo) {
            abort(403);
        }

        // Verificar si estamos dentro del rango del periodo
        $hoy = now()->toDateString();
        $enRango = $hoy >= $periodo->periodo_fecha_inicio->toDateString() && $hoy <= $periodo->periodo_fecha_fin->toDateString();

        $estudiantes = Estudiante::where('colegio_estudiantes.cur_codigo', $asignacion->cur_codigo)
            ->leftJoin('colegio_lista_curso', function ($j) use ($gestion, $asignacion) {
                $j->whereRaw('colegio_estudiantes.est_codigo COLLATE utf8mb4_unicode_ci = colegio_lista_curso.est_codigo')
                  ->where('colegio_lista_curso.lista_gestion', $gestion)
                  ->where('colegio_lista_curso.cur_codigo', $asignacion->cur_codigo);
            })
            ->select('colegio_estudiantes.*', 'colegio_lista_curso.lista_numero')
            ->orderBy('colegio_lista_curso.lista_numero')
            ->orderBy('colegio_estudiantes.est_apellidos')->get();

        $notasExistentes = Nota::with('detalles')
            ->where('curmatdoc_id', $curmatdocId)
            ->where('periodo_id', $periodoId)->get()->keyBy('est_codigo');

        $estadoNotas = $notasExistentes->isNotEmpty() ? $notasExistentes->first()->nota_estado : 0;
        $esAdmin = $user->rol_id == 1;
        // Editable normal: dentro del rango y en estado 0/3 (borrador/rechazado), o aún no hay notas.
        // Admin: SIEMPRE puede editar (queda registrado en auditoría si está fuera de tiempo o aprobado).
        $esEditable = $esAdmin || (($enRango && in_array($estadoNotas, [0, 3])) || !$notasExistentes->count());

        // Datos de auditoría para mostrar al docente
        $notaInfo = $notasExistentes->isNotEmpty() ? $notasExistentes->first() : null;
        $observacionAdmin = $notaInfo->nota_observacion ?? null;
        $fechaAprobacion = $notaInfo->nota_fecha_aprobacion ?? null;
        $aprobadoPor = null;
        if ($notaInfo && $notaInfo->nota_aprobado_por) {
            $aprobadoPor = \App\Models\User::find($notaInfo->nota_aprobado_por);
        }

        // Nombre de cada casillero ("Examen parcial", "Tema 1"...). Si no hay
        // etiqueta cargada, la vista sigue mostrando "Nota N" como antes.
        $etiquetas = \App\Models\NotaColumnaEtiqueta::mapaDe($curmatdocId, $periodoId);

        return view('notas.calificar', compact(
            'asignacion', 'periodo', 'dimensiones', 'estudiantes',
            'notasExistentes', 'estadoNotas', 'enRango', 'esEditable', 'esAdmin',
            'observacionAdmin', 'fechaAprobacion', 'aprobadoPor', 'etiquetas'
        ));
    }

    /**
     * Guarda los nombres de los casilleros de notas de una clase+periodo.
     *
     * Se guarda aparte de las notas para que ponerle nombre a una columna no
     * dependa de que el periodo esté abierto ni de que las notas estén en
     * borrador: es rótulo, no calificación.
     */
    public function guardarEtiquetas(Request $request)
    {
        $request->validate([
            'curmatdoc_id' => 'required',
            'periodo_id'   => 'required',
            'etiquetas'    => 'array',
        ]);

        $asignacion = CursoMateriaDocente::findOrFail($request->curmatdoc_id);
        $user = auth()->user();
        if ($user->us_entidad_tipo === 'docente' && $user->us_entidad_id
            && $user->us_entidad_id !== $asignacion->doc_codigo) {
            abort(403);
        }

        foreach ((array) $request->input('etiquetas', []) as $clave => $nombre) {
            // clave = "dimensionId-columnaNum"
            [$dimId, $col] = array_pad(explode('-', $clave), 2, null);
            if (!is_numeric($dimId) || !is_numeric($col)) continue;

            $nombre = trim(mb_substr((string) $nombre, 0, 60));
            $filtro = [
                'curmatdoc_id' => $request->curmatdoc_id,
                'periodo_id'   => $request->periodo_id,
                'dimension_id' => (int) $dimId,
                'columna_num'  => (int) $col,
            ];

            if ($nombre === '') {
                // Vaciar el campo borra la etiqueta y la columna vuelve a "Nota N".
                \App\Models\NotaColumnaEtiqueta::where($filtro)->delete();
                continue;
            }

            \App\Models\NotaColumnaEtiqueta::updateOrCreate($filtro, [
                'colet_nombre'  => $nombre,
                'colet_usuario' => $user->us_id,
                'colet_fecha'   => now(),
            ]);
        }

        return back()->with('success', 'Nombres de los casilleros guardados.');
    }

    public function guardar(Request $request)
    {
        $curmatdocId = $request->input('curmatdoc_id');
        $periodoId = $request->input('periodo_id');
        $notasInput = $request->input('notas', []);
        $accion = $request->input('accion', 'guardar');

        $asignacion = CursoMateriaDocente::findOrFail($curmatdocId);
        $periodo = NotaPeriodo::findOrFail($periodoId);

        $user = auth()->user();
        if ($user->us_entidad_tipo === 'docente' && $user->us_entidad_id && $user->us_entidad_id !== $asignacion->doc_codigo) {
            abort(403);
        }

        $esAdmin = $user->rol_id == 1;

        // Validar rango de fechas (admin puede saltar esta restricción; queda en auditoría)
        $hoy = now()->toDateString();
        $fueraDeTiempo = ($hoy < $periodo->periodo_fecha_inicio->toDateString() || $hoy > $periodo->periodo_fecha_fin->toDateString());
        if ($fueraDeTiempo && !$esAdmin) {
            return back()->with('error', 'No se pueden registrar notas fuera del rango del periodo (' . $periodo->periodo_fecha_inicio->format('d/m/Y') . ' - ' . $periodo->periodo_fecha_fin->format('d/m/Y') . ')');
        }

        // Snapshot previo para auditoría (solo si admin está cambiando fuera de tiempo o sobre notas aprobadas)
        $estadoPrevio = Nota::where('curmatdoc_id', $curmatdocId)->where('periodo_id', $periodoId)->value('nota_estado');
        $requiereAuditoria = $esAdmin && ($fueraDeTiempo || in_array($estadoPrevio, [2, 3]));
        $snapshotAnterior = null;
        if ($requiereAuditoria) {
            $snapshotAnterior = Nota::with('detalles')->where('curmatdoc_id', $curmatdocId)->where('periodo_id', $periodoId)
                ->get()->map(function($n) {
                    return [
                        'est_codigo' => $n->est_codigo,
                        'promedio'   => $n->nota_promedio_trimestral,
                        'estado'     => $n->nota_estado,
                        'detalles'   => $n->detalles->map(fn($d) => ['dim'=>$d->dimension_id,'col'=>$d->columna_num,'val'=>$d->detalle_valor])->all(),
                    ];
                })->all();
        }

        $gestion = $periodo->periodo_gestion;
        $dimensiones = NotaDimension::activo()->gestion($gestion)->orderBy('dimension_orden')->get();

        foreach ($notasInput as $estCodigo => $dimData) {
            $notaData = ['nota_estado' => $accion === 'enviar' ? 1 : 0];
            if ($accion === 'enviar') {
                $notaData['nota_enviado_por'] = auth()->user()->us_id;
                $notaData['nota_fecha_envio'] = now();
            } else {
                $notaData['nota_guardado_por'] = auth()->user()->us_id;
                $notaData['nota_fecha_guardado'] = now();
            }

            $nota = Nota::updateOrCreate(
                ['periodo_id' => $periodoId, 'curmatdoc_id' => $curmatdocId, 'est_codigo' => $estCodigo],
                $notaData
            );

            // Persistir cada celda y armar el mapa de valores para el service.
            $valoresPorDim = [];
            foreach ($dimensiones as $dim) {
                $valores = $dimData[$dim->dimension_id] ?? [];

                for ($col = 1; $col <= $dim->dimension_columnas; $col++) {
                    $val = isset($valores[$col]) && $valores[$col] !== '' ? floatval($valores[$col]) : null;
                    NotaDetalle::updateOrCreate(
                        ['nota_id' => $nota->nota_id, 'dimension_id' => $dim->dimension_id, 'columna_num' => $col],
                        ['detalle_valor' => $val ?? 0]
                    );
                    $valoresPorDim[$dim->dimension_id][$col] = $val;
                }
            }

            // Fórmula única y compartida con la pantalla: suma de dimensiones
            // redondeadas (oficial) + suma exacta (sólo para cuadro de honor).
            $calc = (new \App\Services\NotaPromedioService())->calcular($dimensiones, $valoresPorDim);

            $nota->update([
                'nota_promedio_trimestral' => $calc['oficial'],
                'nota_promedio_decimal'    => $calc['decimal'],
            ]);
        }

        // Auditoría para cambios admin fuera de tiempo o sobre notas aprobadas/rechazadas
        if ($requiereAuditoria) {
            $snapshotNuevo = Nota::with('detalles')->where('curmatdoc_id', $curmatdocId)->where('periodo_id', $periodoId)
                ->get()->map(function($n) {
                    return [
                        'est_codigo' => $n->est_codigo,
                        'promedio'   => $n->nota_promedio_trimestral,
                        'estado'     => $n->nota_estado,
                        'detalles'   => $n->detalles->map(fn($d) => ['dim'=>$d->dimension_id,'col'=>$d->columna_num,'val'=>$d->detalle_valor])->all(),
                    ];
                })->all();
            // audit_accion es un ENUM('crear','editar','eliminar'): cualquier otro
            // valor lanza "Data truncated" y tumba el guardado con un 500.
            \App\Models\Auditoria::registrar(
                'editar',
                'NOTAS_EDICION_ADMIN',
                'Edición de notas fuera de tiempo/aprobadas por admin — ' .
                    $asignacion->materia->mat_nombre . ' / ' . $asignacion->curso->cur_nombre .
                    ' / ' . $periodo->periodo_nombre .
                    ($fueraDeTiempo ? ' (FUERA DE PERIODO)' : '') .
                    ($estadoPrevio == 2 ? ' (sobre notas APROBADAS)' : ''),
                $curmatdocId,
                $snapshotAnterior,
                $snapshotNuevo
            );
        }

        $msg = $accion === 'enviar' ? 'Notas enviadas para aprobación' : 'Notas guardadas como borrador';
        if ($requiereAuditoria) {
            $msg .= ' (cambio admin registrado en auditoría)';
        }
        return redirect()->route('notas.calificar', [$curmatdocId, $periodoId])->with('success', $msg);
    }

    public function aprobar(Request $request, $curmatdocId, $periodoId)
    {
        $accion = $request->input('accion');
        Nota::where('curmatdoc_id', $curmatdocId)->where('periodo_id', $periodoId)->update([
            'nota_estado' => $accion === 'aprobar' ? 2 : 3,
            'nota_fecha_aprobacion' => now(),
            'nota_aprobado_por' => auth()->user()->us_id,
            'nota_observacion' => $request->input('observacion'),
        ]);
        $msg = $accion === 'aprobar' ? 'Notas aprobadas exitosamente' : 'Notas rechazadas';
        return redirect()->route('notas.calificar', [$curmatdocId, $periodoId])->with('success', $msg);
    }

    public function configuracion()
    {
        $gestion = date('Y');
        $periodos = NotaPeriodo::where('periodo_gestion', $gestion)->orderBy('periodo_numero')->get();
        $dimensiones = NotaDimension::where('dimension_gestion', $gestion)->orderBy('dimension_orden')->get();
        return view('notas.configuracion', compact('periodos', 'dimensiones', 'gestion'));
    }

    // ═══════════════════════════════════════════════════════════════
    // RECÁLCULO DE PROMEDIOS YA GUARDADOS
    // ═══════════════════════════════════════════════════════════════
    //
    // Las notas guardadas antes de unificar la fórmula conservan el promedio
    // viejo (suma de decimales) y siguen imprimiendo un número distinto al que
    // ve el docente en pantalla. Estas dos acciones permiten revisarlas y
    // corregirlas desde Configuración.

    /** Vista previa: qué notas cambiarían. No modifica nada. */
    public function recalculoPreview(Request $request)
    {
        $this->soloAdmin();

        $request->validate([
            'gestion'    => 'required|integer|min:2000|max:2100',
            'periodo_id' => 'nullable|integer',
        ]);

        $periodoId = $request->filled('periodo_id') ? intval($request->periodo_id) : null;

        try {
            $data = (new \App\Services\RecalculoNotasService())
                ->analizar(intval($request->gestion), $periodoId);
        } catch (\Throwable $e) {
            return response()->json([
                'ok'      => false,
                'mensaje' => 'No se pudo analizar: ' . $e->getMessage(),
            ], 500);
        }

        return response()->json(['ok' => true] + $data);
    }

    /**
     * Desglose de una sola nota: celdas por dimensión, promedio exacto y el
     * redondeo aplicado a cada una. Es la justificación del número nuevo.
     */
    public function recalculoDesglose(Request $request)
    {
        $this->soloAdmin();

        $request->validate(['nota_id' => 'required|integer|min:1']);

        try {
            $d = (new \App\Services\RecalculoNotasService())
                ->desglose(intval($request->nota_id));
        } catch (\Throwable $e) {
            return response()->json(['ok' => false, 'mensaje' => $e->getMessage()], 500);
        }

        if (!$d) {
            return response()->json(['ok' => false, 'mensaje' => 'No se encontró la nota.'], 404);
        }

        return response()->json(['ok' => true] + $d);
    }

    /** Aplica el recálculo. Irreversible salvo por la auditoría que deja. */
    public function recalcularEjecutar(Request $request)
    {
        $this->soloAdmin();

        $request->validate([
            'gestion'      => 'required|integer|min:2000|max:2100',
            'periodo_id'   => 'nullable|integer',
            'confirmacion' => 'required|string',
            'notas'        => 'nullable|string',
            'alcance'      => 'nullable|in:todo,seleccion',
        ]);

        if (mb_strtoupper(trim($request->confirmacion)) !== 'RECALCULAR') {
            return back()->with('error', 'Confirmación incorrecta. Debe escribir RECALCULAR para continuar.');
        }

        $periodoId = $request->filled('periodo_id') ? intval($request->periodo_id) : null;

        // Selección hecha en pantalla: lista de nota_id separada por comas.
        // Se manda en un solo campo para no chocar con max_input_vars de PHP.
        $notaIds = null;
        if ($request->input('alcance') === 'seleccion') {
            $notaIds = collect(explode(',', (string) $request->input('notas')))
                ->map(fn($v) => intval(trim($v)))
                ->filter(fn($v) => $v > 0)
                ->unique()
                ->values()
                ->all();

            if (empty($notaIds)) {
                return back()->with('error', 'No seleccionaste ninguna nota para recalcular.');
            }
        }

        try {
            set_time_limit(300);
            $r = (new \App\Services\RecalculoNotasService())
                ->ejecutar(intval($request->gestion), $periodoId, $notaIds);
        } catch (\Throwable $e) {
            return back()->with('error', 'El recálculo falló y no se aplicó ningún cambio: ' . $e->getMessage());
        }

        if ($r['afectadas'] === 0 && $r['decimal_completado'] === 0) {
            return back()->with('success', 'No había nada que corregir: todas las notas del alcance ya estaban bien calculadas.');
        }

        return back()->with('success', sprintf(
            'Recálculo aplicado: %d nota(s) corregida(s)%s. %d registro(s) actualizado(s) en total. Queda constancia en Auditoría.',
            $r['afectadas'],
            $r['cambia_situacion'] > 0
                ? sprintf(', de las cuales %d cambiaron de situación (aprobado/reprobado)', $r['cambia_situacion'])
                : '',
            $r['filas']
        ));
    }

    /** El recálculo toca notas aprobadas: sólo administradores. */
    private function soloAdmin(): void
    {
        if (auth()->user()->rol_id != 1) {
            abort(403, 'Sólo un administrador puede recalcular promedios ya guardados.');
        }
    }

    public function guardarPeriodo(Request $request)
    {
        $request->validate([
            'periodo_nombre' => 'required|max:50',
            'periodo_numero' => 'required|integer|min:1',
            'periodo_fecha_inicio' => 'required|date',
            'periodo_fecha_fin' => 'required|date|after:periodo_fecha_inicio',
        ]);
        NotaPeriodo::updateOrCreate(
            ['periodo_id' => $request->periodo_id],
            $request->only('periodo_nombre', 'periodo_numero', 'periodo_fecha_inicio', 'periodo_fecha_fin', 'periodo_gestion', 'periodo_estado')
        );
        return redirect()->route('notas.configuracion')->with('success', 'Periodo guardado');
    }

    public function eliminarPeriodo($id)
    {
        if (Nota::where('periodo_id', $id)->exists()) {
            return back()->with('error', 'No se puede eliminar, tiene notas asociadas');
        }
        NotaPeriodo::findOrFail($id)->delete();
        return redirect()->route('notas.configuracion')->with('success', 'Periodo eliminado');
    }

    public function guardarDimension(Request $request)
    {
        $request->validate([
            'dimension_nombre' => 'required|max:50',
            'dimension_valor_max' => 'required|integer|min:1|max:100',
            'dimension_columnas' => 'required|integer|min:1|max:10',
        ]);
        NotaDimension::updateOrCreate(
            ['dimension_id' => $request->dimension_id],
            $request->only('dimension_nombre', 'dimension_valor_max', 'dimension_columnas', 'dimension_orden', 'dimension_gestion', 'dimension_estado')
        );
        return redirect()->route('notas.configuracion')->with('success', 'Dimensión guardada');
    }

    public function eliminarDimension($id)
    {
        NotaDimension::findOrFail($id)->delete();
        return redirect()->route('notas.configuracion')->with('success', 'Dimensión eliminada');
    }

    // ═══════════════════════════════════════════════════════════════
    // REPORTE VALORACIÓN TRIMESTRAL (formato Excel)
    // ═══════════════════════════════════════════════════════════════

    public function reporteValoracion($curmatdocId, $periodoId)
    {
        set_time_limit(300);
        ini_set('memory_limit', '512M');

        $asignacion = CursoMateriaDocente::with(['curso', 'materia', 'docente'])->findOrFail($curmatdocId);
        $periodo = NotaPeriodo::findOrFail($periodoId);
        $gestion = $periodo->periodo_gestion;
        $dimensiones = NotaDimension::activo()->gestion($gestion)->orderBy('dimension_orden')->get();

        $estudiantes = Estudiante::where('colegio_estudiantes.cur_codigo', $asignacion->cur_codigo)
            ->leftJoin('colegio_lista_curso', function ($j) use ($gestion, $asignacion) {
                $j->whereRaw('colegio_estudiantes.est_codigo COLLATE utf8mb4_unicode_ci = colegio_lista_curso.est_codigo')
                  ->where('colegio_lista_curso.lista_gestion', $gestion)
                  ->where('colegio_lista_curso.cur_codigo', $asignacion->cur_codigo);
            })
            ->select('colegio_estudiantes.*', 'colegio_lista_curso.lista_numero')
            ->orderBy('colegio_lista_curso.lista_numero')
            ->orderBy('colegio_estudiantes.est_apellidos')->get();

        $notasExistentes = Nota::with('detalles')
            ->where('curmatdoc_id', $curmatdocId)
            ->where('periodo_id', $periodoId)->get()->keyBy('est_codigo');

        $data = [];
        foreach ($estudiantes as $i => $est) {
            $nota = $notasExistentes[$est->est_codigo] ?? null;
            $detallesMap = [];
            if ($nota) {
                foreach ($nota->detalles as $det) {
                    $detallesMap[$det->dimension_id][$det->columna_num] = $det->detalle_valor;
                }
            }

            $fila = [
                'numero' => $est->lista_numero ?? ($i + 1),
                'nombre' => $est->est_apellidos . ' ' . $est->est_nombres,
                'dimensiones' => [],
                'promedio_trimestral' => $nota->nota_promedio_trimestral ?? 0,
                'rango' => '',
            ];

            // Mismo service que la carga: los promedios por dimensión impresos
            // son los mismos enteros con que se armó el PROM. TRIM.
            $svcProm = new \App\Services\NotaPromedioService();
            foreach ($dimensiones as $dim) {
                $valores = [];
                for ($c = 1; $c <= $dim->dimension_columnas; $c++) {
                    $valores[$c] = $detallesMap[$dim->dimension_id][$c] ?? 0;
                }
                $fila['dimensiones'][$dim->dimension_id] = [
                    'valores'  => $valores,
                    'promedio' => (int) round($svcProm->promedioDimension($dim, $valores)),
                ];
            }

            // Rango sobre el ENTERO oficial, para que la etiqueta coincida con el
            // número impreso (antes 66.6 imprimía 67 pero etiquetaba DA en vez de DO).
            $fila['rango'] = $svcProm->rango($fila['promedio_trimestral']);

            $data[] = $fila;
        }

        // Nombres de los casilleros: en la tabla no entran (la celda mide 18px),
        // así que van como referencia al pie del reporte.
        $etiquetas = \App\Models\NotaColumnaEtiqueta::mapaDe($asignacion->curmatdoc_id, $periodo->periodo_id);

        $pdf = Pdf::loadView('notas.reporte-valoracion-pdf', compact(
            'asignacion', 'periodo', 'dimensiones', 'data', 'gestion', 'etiquetas'
        ))->setPaper('legal', 'landscape');

        return $pdf->stream('valoracion-' . $asignacion->cur_codigo . '-' . $asignacion->mat_codigo . '-T' . $periodo->periodo_numero . '.pdf');
    }

    // ═══════════════════════════════════════════════════════════════
    // IMPORTAR EXCEL
    // ═══════════════════════════════════════════════════════════════

    public function importarExcel(Request $request)
    {
        set_time_limit(300);
        ini_set('memory_limit', '512M');

        $request->validate([
            'archivo' => 'required|file|mimes:xlsx,xls|max:10240',
            'curmatdoc_id' => 'required|integer',
            'periodo_id' => 'required|integer',
            'tipo_importacion' => 'required|in:notas,asistencia,ambos',
        ]);

        $asignacion = CursoMateriaDocente::with(['curso', 'materia', 'docente'])->findOrFail($request->curmatdoc_id);
        $periodo = NotaPeriodo::findOrFail($request->periodo_id);
        $gestion = $periodo->periodo_gestion;
        $trimestre = $periodo->periodo_numero;
        $tipo = $request->tipo_importacion;

        // Verificar permisos
        $user = auth()->user();
        if ($user->us_entidad_tipo === 'docente' && $user->us_entidad_id && $user->us_entidad_id !== $asignacion->doc_codigo) {
            return back()->with('error', 'No tiene permisos para importar en esta asignación.');
        }
        $esAdmin = $user->rol_id == 1;

        // Si las notas están aprobadas o fuera de rango, sólo admin puede importar.
        $hoyImp = now()->toDateString();
        $fueraDeTiempoImp = ($hoyImp < $periodo->periodo_fecha_inicio->toDateString() || $hoyImp > $periodo->periodo_fecha_fin->toDateString());
        $estadoActual = Nota::where('curmatdoc_id', $asignacion->curmatdoc_id)->where('periodo_id', $periodo->periodo_id)->value('nota_estado');
        if (!$esAdmin && ($estadoActual == 2 || $fueraDeTiempoImp)) {
            return back()->with('error', 'No puede importar: las notas están aprobadas o fuera del periodo.');
        }
        $requiereAuditoriaImp = $esAdmin && ($estadoActual == 2 || $estadoActual == 3 || $fueraDeTiempoImp);

        // Guardar archivo temporal
        $archivo = $request->file('archivo');
        $nombreArchivo = 'import_' . time() . '_' . $archivo->getClientOriginalName();
        $rutaArchivo = $archivo->storeAs('imports', $nombreArchivo, 'local');
        $rutaCompleta = storage_path('app/' . $rutaArchivo);

        try {
            $service = new ImportarExcelService();
            $service->cargar($rutaCompleta);

            // Validar estructura del Excel
            $erroresEstructura = $service->validarEstructura($trimestre, $tipo);
            if (!empty($erroresEstructura)) {
                @unlink($rutaCompleta);
                return back()->with('error', 'Error en estructura del Excel: ' . implode(' | ', $erroresEstructura));
            }

            // Validar configuración del sistema
            if (in_array($tipo, ['notas', 'ambos'])) {
                $erroresConfig = $service->validarConfiguracion($gestion);
                if (!empty($erroresConfig)) {
                    @unlink($rutaCompleta);
                    return back()->with('error', 'Error de configuración: ' . implode(' | ', $erroresConfig));
                }
            }

            // Parsear datos
            $data = [];
            if (in_array($tipo, ['notas', 'ambos'])) {
                $data['notas'] = $service->parsearNotas($trimestre, $asignacion->cur_codigo, $gestion);
            }
            if (in_array($tipo, ['asistencia', 'ambos'])) {
                $data['asistencia'] = $service->parsearAsistencia($trimestre, $asignacion->cur_codigo);
            }

            $resumen = $service->getResumen();
            $errores = $service->getErrores();

            // Guardar como borrador de importación
            $importacion = ImportacionExcel::create([
                'curmatdoc_id' => $asignacion->curmatdoc_id,
                'periodo_id' => $periodo->periodo_id,
                'import_tipo' => $tipo,
                'import_data' => $data,
                'import_errores' => $errores,
                'import_resumen' => $resumen,
                'import_estado' => 0,
                'import_usuario_id' => auth()->user()->us_id,
                'import_archivo' => $nombreArchivo,
                'import_fecha' => now(),
            ]);

            return redirect()->route('notas.importar-preview', $importacion->import_id);

        } catch (\Exception $e) {
            @unlink($rutaCompleta);
            return back()->with('error', 'Error al procesar el archivo: ' . $e->getMessage());
        }
    }

    public function importarPreview($importId)
    {
        $importacion = ImportacionExcel::findOrFail($importId);

        if ($importacion->import_estado != 0) {
            return redirect()->route('notas.calificar', [$importacion->curmatdoc_id, $importacion->periodo_id])
                ->with('error', 'Esta importación ya fue procesada.');
        }

        // Verificar permisos
        if ($importacion->import_usuario_id != auth()->user()->us_id && auth()->user()->rol_id != 1) {
            abort(403);
        }

        $asignacion = CursoMateriaDocente::with(['curso', 'materia', 'docente'])->findOrFail($importacion->curmatdoc_id);
        $periodo = NotaPeriodo::findOrFail($importacion->periodo_id);
        $dimensiones = NotaDimension::activo()->gestion($periodo->periodo_gestion)->orderBy('dimension_orden')->get();

        return view('notas.importar-preview', compact('importacion', 'asignacion', 'periodo', 'dimensiones'));
    }

    public function importarConfirmar($importId)
    {
        $importacion = ImportacionExcel::findOrFail($importId);

        if ($importacion->import_estado != 0) {
            return redirect()->route('notas.calificar', [$importacion->curmatdoc_id, $importacion->periodo_id])
                ->with('error', 'Esta importación ya fue procesada.');
        }

        if ($importacion->import_usuario_id != auth()->user()->us_id && auth()->user()->rol_id != 1) {
            abort(403);
        }

        $asignacion = CursoMateriaDocente::with(['curso','materia'])->findOrFail($importacion->curmatdoc_id);
        $periodo = NotaPeriodo::findOrFail($importacion->periodo_id);
        $gestion = $periodo->periodo_gestion;
        $data = $importacion->import_data;
        $tipo = $importacion->import_tipo;

        // Detectar si se requiere auditoría (admin importando fuera de tiempo o sobre aprobadas/rechazadas)
        $userConf = auth()->user();
        $esAdminConf = $userConf->rol_id == 1;
        $hoyConf = now()->toDateString();
        $fueraConf = ($hoyConf < $periodo->periodo_fecha_inicio->toDateString() || $hoyConf > $periodo->periodo_fecha_fin->toDateString());
        $estadoPrevConf = Nota::where('curmatdoc_id', $asignacion->curmatdoc_id)->where('periodo_id', $periodo->periodo_id)->value('nota_estado');
        $requiereAuditoriaConf = $esAdminConf && ($fueraConf || in_array($estadoPrevConf, [2, 3]));
        $snapshotAntesConf = null;
        if ($requiereAuditoriaConf) {
            $snapshotAntesConf = Nota::with('detalles')->where('curmatdoc_id', $asignacion->curmatdoc_id)->where('periodo_id', $periodo->periodo_id)
                ->get()->map(function($n) {
                    return [
                        'est_codigo' => $n->est_codigo,
                        'promedio'   => $n->nota_promedio_trimestral,
                        'estado'     => $n->nota_estado,
                        'detalles'   => $n->detalles->map(fn($d) => ['dim'=>$d->dimension_id,'col'=>$d->columna_num,'val'=>$d->detalle_valor])->all(),
                    ];
                })->all();
        }

        DB::beginTransaction();
        try {
            // ── Importar NOTAS ──
            if (in_array($tipo, ['notas', 'ambos']) && !empty($data['notas'])) {
                $dimensiones = NotaDimension::activo()->gestion($gestion)->orderBy('dimension_orden')->get();

                foreach ($data['notas'] as $notaEst) {
                    $nota = Nota::updateOrCreate(
                        ['periodo_id' => $periodo->periodo_id, 'curmatdoc_id' => $asignacion->curmatdoc_id, 'est_codigo' => $notaEst['est_codigo']],
                        [
                            'nota_estado' => 0, // Borrador
                            'nota_guardado_por' => auth()->user()->us_id,
                            'nota_fecha_guardado' => now(),
                        ]
                    );

                    // Persistir cada celda (evidencia de la nota) y armar el mapa
                    // de valores por dimensión para el fallback de cálculo.
                    $valoresPorDim = [];
                    $sumaPromExcel = 0.0;
                    $hayPromExcel  = false;

                    foreach ($notaEst['dimensiones'] as $dimId => $dimData) {
                        $dim = $dimensiones->firstWhere('dimension_id', $dimId);
                        if (!$dim) continue;

                        $valores = $dimData['valores'] ?? [];

                        for ($col = 1; $col <= $dim->dimension_columnas; $col++) {
                            $val = $valores[$col] ?? 0;
                            NotaDetalle::updateOrCreate(
                                ['nota_id' => $nota->nota_id, 'dimension_id' => $dimId, 'columna_num' => $col],
                                ['detalle_valor' => $val]
                            );
                            $valoresPorDim[$dimId][$col] = $val;
                        }

                        // Promedio que el propio Excel calculó para esta dimensión
                        // (columnas G / R / AC de la plantilla).
                        $pe = (float) ($dimData['promedio_excel'] ?? 0);
                        if ($pe > 0) {
                            $hayPromExcel = true;
                            $sumaPromExcel += min($pe, (float) $dim->dimension_valor_max);
                        }
                    }

                    $svcProm = new \App\Services\NotaPromedioService();

                    // ── Se RESPETA la nota cargada del Excel ────────────────────
                    // 1º el PROM. TRIM. de la plantilla (celda AG) — es exactamente
                    //    lo que el docente aprobó en la vista previa.
                    // 2º si AG viene vacía, la suma de los promedios por dimensión
                    //    que el Excel sí calculó (G / R / AC).
                    // 3º si tampoco, se recalcula desde las celdas con la misma
                    //    fórmula que usa la pantalla del docente.
                    $promExcelTrim = (float) ($notaEst['promedio_trimestral'] ?? 0);

                    if ($promExcelTrim > 0) {
                        $oficial = (int) round($promExcelTrim);
                        $decimal = round($promExcelTrim, 2);
                    } elseif ($hayPromExcel) {
                        $oficial = (int) round($sumaPromExcel);
                        $decimal = round($sumaPromExcel, 2);
                    } else {
                        $calc    = $svcProm->calcular($dimensiones, $valoresPorDim);
                        $oficial = $calc['oficial'];
                        $decimal = $calc['decimal'];
                    }

                    $nota->update([
                        'nota_promedio_trimestral' => $oficial,
                        'nota_promedio_decimal'    => $decimal,
                    ]);
                }
            }

            // ── Importar ASISTENCIA ──
            if (in_array($tipo, ['asistencia', 'ambos']) && !empty($data['asistencia'])) {
                foreach ($data['asistencia'] as $asisEst) {
                    foreach ($asisEst['registros'] as $reg) {
                        AsistenciaClase::updateOrCreate(
                            [
                                'curmatdoc_id' => $asignacion->curmatdoc_id,
                                'periodo_id' => $periodo->periodo_id,
                                'est_codigo' => $asisEst['est_codigo'],
                                'asiscl_fecha' => $reg['fecha'],
                            ],
                            [
                                'asiscl_estado' => $reg['estado'],
                                'asiscl_registrado_por' => auth()->user()->us_id,
                            ]
                        );
                    }
                }
            }

            $importacion->update([
                'import_estado' => 1,
                'import_fecha_confirmacion' => now(),
            ]);

            DB::commit();

            // Limpiar archivo
            $rutaArchivo = storage_path('app/imports/' . $importacion->import_archivo);
            @unlink($rutaArchivo);

            // Auditar import admin sobre aprobadas/rechazadas o fuera de tiempo
            if ($requiereAuditoriaConf) {
                $snapshotDespuesConf = Nota::with('detalles')->where('curmatdoc_id', $asignacion->curmatdoc_id)->where('periodo_id', $periodo->periodo_id)
                    ->get()->map(function($n) {
                        return [
                            'est_codigo' => $n->est_codigo,
                            'promedio'   => $n->nota_promedio_trimestral,
                            'estado'     => $n->nota_estado,
                            'detalles'   => $n->detalles->map(fn($d) => ['dim'=>$d->dimension_id,'col'=>$d->columna_num,'val'=>$d->detalle_valor])->all(),
                        ];
                    })->all();
                \App\Models\Auditoria::registrar(
                    'editar',
                    'NOTAS_IMPORT_EXCEL_ADMIN',
                    'Importación Excel admin — ' . ($asignacion->materia->mat_nombre ?? '') . ' / ' . ($asignacion->curso->cur_nombre ?? '') .
                        ' / ' . $periodo->periodo_nombre .
                        ($fueraConf ? ' (FUERA DE PERIODO)' : '') .
                        ($estadoPrevConf == 2 ? ' (sobre notas APROBADAS)' : '') .
                        ($estadoPrevConf == 3 ? ' (sobre notas RECHAZADAS)' : ''),
                    $importacion->import_id,
                    $snapshotAntesConf,
                    $snapshotDespuesConf
                );
            }

            $msg = 'Importación completada exitosamente.';
            if (in_array($tipo, ['notas', 'ambos'])) $msg .= ' Notas guardadas como BORRADOR.';
            if (in_array($tipo, ['asistencia', 'ambos'])) $msg .= ' Asistencia registrada.';
            if ($requiereAuditoriaConf) $msg .= ' (Cambio admin registrado en auditoría)';

            return redirect()->route('notas.calificar', [$asignacion->curmatdoc_id, $periodo->periodo_id])
                ->with('success', $msg);

        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->route('notas.importar-preview', $importId)
                ->with('error', 'Error al confirmar importación: ' . $e->getMessage());
        }
    }

    public function importarCancelar($importId)
    {
        $importacion = ImportacionExcel::findOrFail($importId);

        if ($importacion->import_usuario_id != auth()->user()->us_id && auth()->user()->rol_id != 1) {
            abort(403);
        }

        $curmatdocId = $importacion->curmatdoc_id;
        $periodoId = $importacion->periodo_id;

        // Limpiar archivo
        $rutaArchivo = storage_path('app/imports/' . $importacion->import_archivo);
        @unlink($rutaArchivo);

        $importacion->update(['import_estado' => 2]);

        return redirect()->route('notas.calificar', [$curmatdocId, $periodoId])
            ->with('success', 'Importación cancelada.');
    }

    // ═══════════════════════════════════════════════════════════════
    // REPORTES
    // ═══════════════════════════════════════════════════════════════

    private function getEstudiantesOrdenados($curCodigo, $gestion)
    {
        $lista = ListaCurso::where('cur_codigo', $curCodigo)
            ->where('lista_gestion', $gestion)->pluck('lista_numero', 'est_codigo');

        // Incluye retirados; en los PDFs se renderizan en rojo con badge RETIRADO
        $estudiantes = Estudiante::where('cur_codigo', $curCodigo)
            ->orderBy('est_apellidos')->orderBy('est_nombres')->get();

        if ($lista->isNotEmpty()) {
            $estudiantes = $estudiantes->sortBy(fn($e) => $lista[$e->est_codigo] ?? 9999)->values();
        }
        return [$estudiantes, $lista];
    }

    /**
     * Lectura de notas del boletín. Vive en BoletinNotasService para que el
     * cuadro de honor use exactamente los mismos números; se conserva una
     * instancia por request para aprovechar su caché por curso y periodo.
     */
    private ?\App\Services\BoletinNotasService $boletinNotas = null;

    private function boletinNotas(): \App\Services\BoletinNotasService
    {
        return $this->boletinNotas ??= new \App\Services\BoletinNotasService();
    }

    private function getMateriasDelCurso($curCodigo)
    {
        return $this->boletinNotas()->materiasDelCurso($curCodigo);
    }

    private function getNotaPromedio($estCodigo, $curCodigo, $matCodigo, $periodoId)
    {
        return $this->boletinNotas()->notaPromedio($estCodigo, $curCodigo, $matCodigo, $periodoId);
    }

    /**
     * Calcula días hábiles (lun-vie) en un rango, excluyendo festivos.
     */
    private function diasHabilesRango($fechaInicio, $fechaFin, $year)
    {
        $feriados = FechaFestiva::activo()->feriado()
            ->whereYear('festivo_fecha', $year)
            ->pluck('festivo_fecha')->map(fn($f) => $f->format('Y-m-d'))->toArray();

        $dias = 0;
        $current = Carbon::parse($fechaInicio)->copy();
        $fin = Carbon::parse($fechaFin);
        while ($current <= $fin) {
            if ($current->isWeekday() && !in_array($current->format('Y-m-d'), $feriados)) {
                $dias++;
            }
            $current->addDay();
        }
        return $dias;
    }

    /**
     * Asistencia institucional por trimestre usando las fechas exactas del periodo.
     * Cuenta solo lun-vie, excluye festivos.
     */

    /**
     * Instancia compartida por turno del resumen de asistencia.
     *
     * El service cachea internamente lo que no depende del estudiante (feriados,
     * días trabajados del colegio, configuración del curso). Crear uno nuevo por
     * estudiante tiraba ese cache y repetía ~38 consultas por alumno.
     *
     * @var array<string, \App\Services\AsistenciaResumenService>
     */
    private array $resumenServices = [];

    private function resumenService(string $turno = 'Mañana'): \App\Services\AsistenciaResumenService
    {
        return $this->resumenServices[$turno] ??= new \App\Services\AsistenciaResumenService($turno);
    }

    private function getAsistenciaTrimestreEst($estCodigo, $periodo, $year)
    {
        $service = $this->resumenService();

        // Si el periodo no terminó y no hay notas aprobadas → no mostrar nada.
        if (!$service->periodoVisible($periodo)) {
            return ['dt' => 0, 'ta' => 0, 'tl' => 0, 'tf' => 0, 'pres' => 0, 'total' => 0, 'visible' => false];
        }

        $r = $service->resumen(
            $estCodigo,
            $periodo->periodo_fecha_inicio->format('Y-m-d'),
            $periodo->periodo_fecha_fin->format('Y-m-d')
        );

        return [
            'dt'      => $r['dias_trabajados_curso'],      // mismo significado que en el detalle
            'ta'      => $r['atrasos'],
            'tl'      => $r['licencias_dias'],
            'tf'      => $r['faltas'],
            'pres'    => $r['presencias'],
            'total'   => $r['dias_habiles_calendario'],    // total días hábiles del calendario (L-V del rango)
            'visible' => true,
        ];
    }

    private function getEnfermeriaTrimestreEst($estCodigo, $periodo)
    {
        $higiene = RegistroEnfermeria::activo()->where('est_codigo', $estCodigo)
            ->where('enf_tipo_persona', 'ESTUDIANTE')
            ->where('enf_dx_detalle', 'LIKE', '%HIGIENE%')
            ->whereBetween('enf_fecha', [$periodo->periodo_fecha_inicio, $periodo->periodo_fecha_fin])->count();
        $atencion = RegistroEnfermeria::activo()->where('est_codigo', $estCodigo)
            ->where('enf_tipo_persona', 'ESTUDIANTE')
            ->where('enf_dx_detalle', 'NOT LIKE', '%HIGIENE%')
            ->whereBetween('enf_fecha', [$periodo->periodo_fecha_inicio, $periodo->periodo_fecha_fin])->count();
        return compact('higiene', 'atencion');
    }

    /**
     * Control y Seguimiento del boletín: llamadas y compromisos del trimestre.
     *
     * En COMPROMISOS sólo cuentan los ESCRITOS. `psico_tipo_acuerdo` admite
     * VERBAL, ESCRITO y NINGUNO; antes se contaba como compromiso todo lo que no
     * fuera NINGUNO, así que los acuerdos verbales inflaban la columna SI.
     * La columna NO son los casos del trimestre sin compromiso escrito, de modo
     * que SI + NO sigue siendo el total de casos.
     */
    private function getPsicoTrimestreEst($estCodigo, $periodo)
    {
        $llamadas = CasoPsicopedagogia::activo()->where('est_codigo', $estCodigo)
            ->whereBetween('psico_fecha', [$periodo->periodo_fecha_inicio, $periodo->periodo_fecha_fin])->count();
        $compromisosSi = CasoPsicopedagogia::activo()->where('est_codigo', $estCodigo)
            ->where('psico_tipo_acuerdo', 'ESCRITO')
            ->whereBetween('psico_fecha', [$periodo->periodo_fecha_inicio, $periodo->periodo_fecha_fin])->count();

        return [
            'llamadas_si'     => $llamadas,
            'llamadas_no'     => 0,
            'compromisos_si'  => $compromisosSi,
            'compromisos_no'  => max(0, $llamadas - $compromisosSi),
        ];
    }

    /**
     * REPORTE 1: Personal del Estudiante (boletín individual)
     */
    public function reportePersonal(Request $request)
    {
        $request->validate(['est_codigo' => 'required']);
        $gestion = $request->input('gestion', date('Y'));

        $estudiante = Estudiante::where('est_codigo', $request->est_codigo)->with('curso')->firstOrFail();
        $curso = $estudiante->curso;
        $periodos = NotaPeriodo::activo()->gestion($gestion)->orderBy('periodo_numero')->get();

        $lista = ListaCurso::where('cur_codigo', $curso->cur_codigo)
            ->where('lista_gestion', $gestion)->where('est_codigo', $estudiante->est_codigo)->first();
        $nroLista = $lista->lista_numero ?? '-';

        $asignaciones = $this->getMateriasDelCurso($curso->cur_codigo);

        // Agrupar materias por campo
        $materiasPorCampo = $asignaciones->groupBy(fn($cmd) => $cmd->materia->mat_campo ?: 'SIN CAMPO');

        // Notas por materia y periodo (mismo cálculo que el cuadro de honor)
        $notasData = $this->boletinNotas()->notasEstudiante($estudiante->est_codigo, $curso->cur_codigo, $periodos);

        // Configuración por curso (campo, orden, promediable). Si la pivote está vacía
        // para este curso cae al modo global automáticamente.
        $configCurso = (new \App\Services\MateriaCursoService())->configPorCurso($curso->cur_codigo);

        // Reagrupar materias usando el campo CONFIGURADO POR CURSO (no el global).
        $materiasPorCampo = $asignaciones->groupBy(function($cmd) use ($configCurso) {
            return $configCurso[$cmd->mat_codigo]->campo
                ?? ($cmd->materia->mat_campo ?: 'SIN CAMPO');
        });

        // Promedios por campo — sólo materias con promediable=1 EN EL CURSO
        $promediosCampo = [];
        foreach ($materiasPorCampo as $campo => $cmds) {
            $cmdsProm = $cmds->filter(function($cmd) use ($configCurso) {
                $cfg = $configCurso[$cmd->mat_codigo] ?? null;
                if ($cfg) return $cfg->promediable === 1;
                return (int) ($cmd->materia->mat_promediable ?? 0) === 1;
            });
            $promediosCampo[$campo]['cnt_promediable'] = $cmdsProm->count();
            foreach ($periodos as $p) {
                $s = 0; $c = 0;
                foreach ($cmdsProm as $cmd) {
                    $v = $notasData[$cmd->mat_codigo]['trimestres'][$p->periodo_numero] ?? 0;
                    if ($v > 0) { $s += $v; $c++; }
                }
                $promediosCampo[$campo][$p->periodo_numero] = $c > 0 ? round($s / $c) : 0;
            }
            $vals = array_filter(array_values(array_intersect_key(
                $promediosCampo[$campo],
                array_flip($periodos->pluck('periodo_numero')->all())
            )));
            $promediosCampo[$campo]['anual'] = count($vals) > 0 ? round(array_sum($vals) / count($vals)) : 0;
        }

        // Asistencia, enfermería, psicopedagogía por trimestre
        $year = intval($gestion);
        $asistData = []; $enfData = []; $psicoData = [];
        foreach ($periodos as $p) {
            $asistData[$p->periodo_numero] = $this->getAsistenciaTrimestreEst($estudiante->est_codigo, $p, $year);
            $enfData[$p->periodo_numero] = $this->getEnfermeriaTrimestreEst($estudiante->est_codigo, $p);
            $psicoData[$p->periodo_numero] = $this->getPsicoTrimestreEst($estudiante->est_codigo, $p);
        }

        // Grupos derivados de mat_campo: cada campo (área) es un grupo natural.
        [$gruposActivos, $gruposMap] = $this->buildGruposPorCampo($curso->cur_codigo ?? null);

        // ── Registro de descarga + QR de autenticación ───────────────────
        $trimestreParam = $request->input('trimestre'); // null = anual
        $token          = bin2hex(random_bytes(20)); // 40 chars
        $copiasPrevias  = \App\Models\BoletinDescarga::where('est_codigo', $estudiante->est_codigo)
            ->where('descarga_gestion', (int) $gestion)
            ->where('descarga_anulada', 0)
            ->where(function($q) use ($trimestreParam) {
                if ($trimestreParam) $q->where('descarga_trimestre', $trimestreParam);
                else                 $q->whereNull('descarga_trimestre');
            })->count();
        $numeroCopia = $copiasPrevias + 1;
        $cobrable    = $numeroCopia > 1;
        $user        = auth()->user();

        \App\Models\BoletinDescarga::create([
            'descarga_token'        => $token,
            'est_codigo'            => $estudiante->est_codigo,
            'descarga_gestion'      => (int) $gestion,
            'descarga_trimestre'    => $trimestreParam ?: null,
            'descargado_por'        => $user ? $user->us_id : null,
            'descargado_por_nombre' => $user ? trim(($user->us_nombres ?? '') . ' ' . ($user->us_apellidos ?? '')) : null,
            'descarga_fecha'        => now(),
            'descarga_ip'           => request()->ip(),
            'descarga_user_agent'   => substr(request()->userAgent() ?? '', 0, 255),
            'descarga_numero_copia' => $numeroCopia,
            'descarga_cobrable'     => $cobrable ? 1 : 0,
        ]);

        $qrUrl  = url('/boletin/validar/' . $token);
        $qrData = null;
        try {
            $qrData = (new \chillerlan\QRCode\QRCode(
                new \chillerlan\QRCode\QROptions([
                    'outputType' => \chillerlan\QRCode\QRCode::OUTPUT_IMAGE_PNG,
                    'eccLevel'   => \chillerlan\QRCode\QRCode::ECC_L,
                    'scale'      => 3,
                    'imageBase64'=> true,
                ])
            ))->render($qrUrl);
        } catch (\Throwable $e) {
            $qrData = null;
        }

        $pdf = Pdf::loadView('notas.reporte-personal-pdf', compact(
            'estudiante', 'curso', 'periodos', 'materiasPorCampo', 'notasData',
            'promediosCampo', 'asistData', 'enfData', 'psicoData', 'nroLista', 'gestion',
            'gruposMap', 'gruposActivos',
            'token', 'qrUrl', 'qrData', 'numeroCopia', 'cobrable'
        ))->setPaper('letter', 'portrait');

        return $pdf->stream('boletin-' . $estudiante->est_codigo . '.pdf');
    }

    /**
     * Vista pública de validación de un boletín a partir del token del QR.
     */
    public function validarBoletin($token)
    {
        $descarga = \App\Models\BoletinDescarga::with('estudiante.curso')
            ->where('descarga_token', $token)->first();

        if (!$descarga) {
            return response()->view('notas.boletin-validar', ['valido' => false], 404);
        }

        $totalCopias = \App\Models\BoletinDescarga::where('est_codigo', $descarga->est_codigo)
            ->where('descarga_gestion', $descarga->descarga_gestion)
            ->where(function($q) use ($descarga) {
                if ($descarga->descarga_trimestre) $q->where('descarga_trimestre', $descarga->descarga_trimestre);
                else                                $q->whereNull('descarga_trimestre');
            })->count();

        return view('notas.boletin-validar', [
            'valido'     => true,
            'descarga'   => $descarga,
            'totalCopias'=> $totalCopias,
        ]);
    }

    /**
     * REPORTE 2: Centralizador (todas las materias de un curso, por trimestre o anual)
     */
    public function reporteCentralizador(Request $request)
    {
        $request->validate(['cur_codigo' => 'required']);
        $gestion = $request->input('gestion', date('Y'));
        $year = intval($gestion);
        $periodoId = $request->input('periodo_id');

        $curso = Curso::where('cur_codigo', $request->cur_codigo)->firstOrFail();
        $periodos = $periodoId
            ? NotaPeriodo::where('periodo_id', $periodoId)->get()
            : NotaPeriodo::activo()->gestion($gestion)->orderBy('periodo_numero')->get();
        [$estudiantes, $lista] = $this->getEstudiantesOrdenados($curso->cur_codigo, $gestion);
        $asignaciones = $this->getMateriasDelCurso($curso->cur_codigo);

        if ($estudiantes->isEmpty()) return back()->with('error', 'No hay estudiantes en ' . $curso->cur_nombre);

        // Construir datos: por cada estudiante, por cada materia, los 3 trimestres + promedio
        $data = [];
        foreach ($estudiantes as $est) {
            // Mismo cálculo que usa el cuadro de honor (BoletinNotasService).
            $calc = $this->boletinNotas()->filaCentralizador($est->est_codigo, $curso->cur_codigo, $periodos);
            $fila = [
                'estudiante' => $est,
                'materias'   => $calc['materias'],
                'suma'       => $calc['suma'],
                'promedio'   => $calc['promedio'],
            ];

            // Asistencia institucional (DT, TA, TL, TF)
            $asist = [];
            foreach ($periodos as $p) {
                $asist[$p->periodo_numero] = $this->getAsistenciaTrimestreEst($est->est_codigo, $p, $year);
            }
            $fila['asistencia'] = $asist;

            // Psicopedagogía
            $psico = [];
            foreach ($periodos as $p) {
                $psico[$p->periodo_numero] = $this->getPsicoTrimestreEst($est->est_codigo, $p);
            }
            $fila['psico'] = $psico;

            // Enfermería total
            $enfTotal = RegistroEnfermeria::activo()->where('est_codigo', $est->est_codigo)
                ->where('enf_tipo_persona', 'ESTUDIANTE')
                ->whereYear('enf_fecha', $year)->count();
            $fila['enfermeria'] = $enfTotal;

            $data[] = $fila;
        }

        // Grupos derivados de mat_campo: cada campo (área) es un grupo natural.
        [$gruposActivos, $gruposMap] = $this->buildGruposPorCampo($curso->cur_codigo ?? null);

        $pdf = Pdf::loadView('notas.reporte-centralizador-pdf', compact(
            'curso', 'periodos', 'asignaciones', 'data', 'lista', 'gestion',
            'gruposMap', 'gruposActivos'
        ))->setPaper('legal', 'landscape');

        return $pdf->stream('centralizador-' . $curso->cur_codigo . '.pdf');
    }

    /**
     * REPORTE 3: General de Notas (por trimestre o todos, con detalle de dimensiones)
     */
    public function reporteGeneral(Request $request)
    {
        $request->validate(['cur_codigo' => 'required']);
        $gestion = $request->input('gestion', date('Y'));
        $year = intval($gestion);
        $periodoId = $request->input('periodo_id');

        $curso = Curso::where('cur_codigo', $request->cur_codigo)->firstOrFail();
        $periodos = $periodoId
            ? NotaPeriodo::where('periodo_id', $periodoId)->get()
            : NotaPeriodo::activo()->gestion($gestion)->orderBy('periodo_numero')->get();

        [$estudiantes, $lista] = $this->getEstudiantesOrdenados($curso->cur_codigo, $gestion);
        $asignaciones = $this->getMateriasDelCurso($curso->cur_codigo);

        if ($estudiantes->isEmpty()) return back()->with('error', 'No hay estudiantes en ' . $curso->cur_nombre);

        // Datos: por estudiante, por materia, por trimestre = nota + promedio materia
        $data = [];
        foreach ($estudiantes as $est) {
            $fila = ['estudiante' => $est, 'materias' => [], 'suma' => 0, 'promedio' => 0];
            $sumaTotal = 0; $countTotal = 0;

            foreach ($asignaciones as $cmd) {
                $mat = $cmd->mat_codigo;
                $trimestres = [];
                $sumaMat = 0; $countMat = 0;
                foreach ($periodos as $p) {
                    $val = $this->getNotaPromedio($est->est_codigo, $curso->cur_codigo, $mat, $p->periodo_id);
                    $trimestres[$p->periodo_numero] = $val;
                    if ($val > 0) { $sumaMat += $val; $countMat++; }
                }
                $promMat = $countMat > 0 ? round($sumaMat / $countMat, 1) : 0;
                $fila['materias'][$mat] = ['trimestres' => $trimestres, 'promedio' => $promMat];
                $sumaTotal += $sumaMat;
                if ($promMat > 0) $countTotal++;
            }

            $fila['suma'] = $sumaTotal;
            $fila['promedio'] = $countTotal > 0 ? round($sumaTotal / ($countTotal * $periodos->count()), 1) : 0;

            // Asistencia
            $asist = [];
            foreach ($periodos as $p) {
                $asist[$p->periodo_numero] = $this->getAsistenciaTrimestreEst($est->est_codigo, $p, $year);
            }
            $fila['asistencia'] = $asist;

            $data[] = $fila;
        }

        $esTrimestre = $periodoId ? true : false;
        $periodoNombre = $periodoId ? $periodos->first()->periodo_nombre : 'AÑO ESCOLAR';

        // Grupos derivados de mat_campo: cada campo (área) es un grupo natural.
        [$gruposActivos, $gruposMap] = $this->buildGruposPorCampo($curso->cur_codigo ?? null);

        // El trimestral entra en Carta apaisada; el anual no, porque cada materia
        // pasa de 1 a 4 columnas (T1/T2/T3 + promedio) más 5 de asistencia por
        // trimestre. Oficio apaisado da 27% más de ancho.
        //
        // Medido sobre 5toPRIM (37 alumnos, 12 materias, 65 columnas):
        // Carta 7 hojas → Oficio 5 hojas, con la misma letra. Bajar la fuente
        // llega a 3 hojas y ahí toca piso: "el anual en 1 sola hoja" no es
        // alcanzable con texto legible para un curso de ese tamaño. Las palancas
        // que quedan son A3 (3 hojas) o sacar el bloque de asistencia por
        // trimestre; las dos son decisión del colegio.
        $papel = $esTrimestre ? 'letter' : 'legal';

        $pdf = Pdf::loadView('notas.reporte-general-pdf', compact(
            'curso', 'periodos', 'asignaciones', 'data', 'lista', 'gestion',
            'esTrimestre', 'periodoNombre', 'gruposMap', 'gruposActivos'
        ))->setPaper($papel, 'landscape');

        return $pdf->stream('notas-general-' . $curso->cur_codigo . '.pdf');
    }

    /**
     * Construye los grupos de materias a partir de mat_campo.
     * Devuelve [Collection $gruposActivos, array $gruposMap (mat_codigo => grupo)].
     * Cada "grupo" es un objeto sintético con grupo_id, grupo_nombre, materias y materiasPromediables.
     */
    /**
     * Construye los grupos por campo.
     * Si se proporciona $curCodigo, usa la configuración por curso (colegio_materia_curso);
     * en su defecto, cae al modo legacy global.
     */
    private function buildGruposPorCampo(?string $curCodigo = null)
    {
        if ($curCodigo) {
            return (new \App\Services\MateriaCursoService())->gruposPorCampo($curCodigo);
        }
        return (new \App\Services\MateriaCursoService())->gruposPorCampo('__legacy__');
    }
}
